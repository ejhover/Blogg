# You can run the app by running the command `node server.js` from the `/project` directory after running `npm install` to install dependencies.
# Make a profile an admin by visiting `/admin` while logged into that user account or sending a GET request to `/admin` with req.session.user being the user you want to become an admin.
# To edit, comment, or delete a post you must go to its post page by clicking Show More... or navigating to `/post/{id}` with the posts' id.
# Pick your own theme with the dark mode toggle button on the top right corner of the screen! 
# Click user's names to visit their personal page with all of their posts!
# Use search bar on the left hand side of the home page to search through the posts!